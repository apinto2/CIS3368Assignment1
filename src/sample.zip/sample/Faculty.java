package sample;

public class Faculty extends Employee {

    public  String officeHours;
}
