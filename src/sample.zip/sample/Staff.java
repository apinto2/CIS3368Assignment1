package sample;

public class Staff extends Employee{

    public int accessLevel;
}
